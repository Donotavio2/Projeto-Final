
package com.example.projetofinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.DatePicker;


import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddTaskActivity extends AppCompatActivity {
    private EditText mTitleEditText;
    private EditText mDescriptionEditText;
    private EditText mTimeEditText;
    private EditText mDateEditText;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        mTitleEditText = findViewById(R.id.title_edit_text);
        mDescriptionEditText = findViewById(R.id.description_edit_text);
        mTimeEditText = findViewById(R.id.time_text_view);
        mDateEditText = findViewById(R.id.date_text_view);


        Button addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = mTitleEditText.getText().toString();
                String description = mDescriptionEditText.getText().toString();
                String date = mDateEditText.getText().toString();
                String time = mTimeEditText.getText().toString();



                if (!title.isEmpty() && !description.isEmpty()) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("id", generateId());
                    resultIntent.putExtra("title", title);
                    resultIntent.putExtra("description", description);
                    resultIntent.putExtra("date", date);
                    resultIntent.putExtra("time", time);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    Toast.makeText(AddTaskActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private int generateId() {
        // Lógica para gerar um ID único para a tarefa
        return (int) (System.currentTimeMillis() / 1000);
    }

}
