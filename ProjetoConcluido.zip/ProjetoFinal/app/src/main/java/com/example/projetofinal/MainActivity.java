
package com.example.projetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.EditText;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView mTaskListView;
    private List<Task> mTasks;
    private TaskAdapter mAdapter;
    private TextView emptyMessageTextView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emptyMessageTextView = findViewById(R.id.empty_message_text_view);

        mTaskListView = findViewById(R.id.task_list_view);
        mTasks = new ArrayList<>();

        mAdapter = new TaskAdapter(this, mTasks);
        mTaskListView.setAdapter(mAdapter);

        updateEmptyMessageVisibility();

        FloatingActionButton fab = findViewById(R.id.add_task_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAddTaskActivity();
            }
        });
    }

    private void openAddTaskActivity() {
        Intent intent = new Intent(this, AddTaskActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                int id = data.getIntExtra("id", 0);
                String title = data.getStringExtra("title");
                String description = data.getStringExtra("description");
                String date = data.getStringExtra("date");
                String time = data.getStringExtra("time");

                Task newTask = new Task(id, title, description, date, time);
                mTasks.add(newTask);
                mAdapter.notifyDataSetChanged();

                updateEmptyMessageVisibility();
            }
        }
    }

    private void updateEmptyMessageVisibility() {
        if (mTasks.isEmpty()) {
            emptyMessageTextView.setVisibility(View.VISIBLE);
        } else {
            emptyMessageTextView.setVisibility(View.GONE);
        }
    }
}
