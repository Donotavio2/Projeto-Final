package com.example.projetofinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;

public class TaskAdapter extends ArrayAdapter<Task> {
    private Context mContext;
    private List<Task> mTasks;

    public TaskAdapter(Context context, List<Task> tasks) {
        super(context, 0, tasks);
        mContext = context;
        mTasks = tasks;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(mContext).inflate(R.layout.task_item, parent, false);
        }

        final Task currentTask = mTasks.get(position);

        TextView titleTextView = listItem.findViewById(R.id.title_text_view);
        titleTextView.setText(currentTask.getTitle());

        TextView descriptionTextView = listItem.findViewById(R.id.description_text_view);
        descriptionTextView.setText(currentTask.getDescription());

        TextView dateTextView = listItem.findViewById(R.id.date_text_view);
        if (currentTask.getDate() != null) {
            dateTextView.setText("Data: " + currentTask.getDate());
        } else {
            dateTextView.setText("");
        }

        TextView timeTextView = listItem.findViewById(R.id.time_text_view);
        if (currentTask.getTime() != null) {
            timeTextView.setText("Hora: " + currentTask.getTime());
        } else {
            timeTextView.setText("");
        }

        ImageButton deleteButton = listItem.findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTasks.remove(position);
                notifyDataSetChanged();
            }
        });

        return listItem;
    }
}

